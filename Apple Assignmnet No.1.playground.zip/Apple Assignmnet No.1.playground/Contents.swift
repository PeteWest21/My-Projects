import UIKit


//Constants
let L = 20.0
let B = 38.0
let pi = 3.142
let seed = 50.0
let workcost = 175
let radius = 4.0
let diameter = 8
let wage:Double = 175
let seedprice1 = 13.06
let seedprice2 = 15.20
let seedprice3 = 18.09

//variables and calculations
var parkarea = L * B

var circFB1:Double = ((pi) * radius * radius)

var circFB2:Double = ((pi) * radius * radius)

var diamondFB3:Double = 2*(0.5*4*5)
//area of diamond;

var totalFBArea = (circFB1) + (circFB2)  + (diamondFB3)

var totallawnarea = parkarea-(totalFBArea)

//area of lawn
print (totallawnarea)
 
var Qtyseed = totallawnarea / seed
print(Qtyseed)
var totalcost = 0.0
var costSeedRequired = 0.0






print(Qtyseed)
 //Testcondutional 1;If the weight of grass-seed is less then 10kg then the cost per kilo is €13.09;
if (Qtyseed < 10){
    costSeedRequired = Qtyseed * seedprice1
    totalcost = costSeedRequired + 175
    outputDetails()
    print (totalcost)
}//testconductional 2;If he weight of the grass-seed is between 10kg and 15kg the cost is €15.20 per kilo anything else is coming in at a cost of €18.09 per kilo;
else if (Qtyseed >= 10 || Qtyseed <= 15)
    {
       costSeedRequired = Qtyseed * seedprice2
     totalcost = costSeedRequired + 175
     outputDetails()
     print(totalcost)

}
//Testconductional 3; An additional charge of €175 euro is also to be included in the cost of carrying out the work;ßS
else{
    costSeedRequired = Qtyseed * seedprice3
    totalcost = costSeedRequired + 175
    outputDetails()
    print(totalcost)
}

//Output results on screen
    func outputDetails(){
        print("Area of the lawn is ")
        print(parkarea)
        print("Area of the circular beds")
        print(circFB1)
        print(circFB2)
        print("Area of the diamond")
        print(diamondFB3)
        print("The cost of carring out the work")
        print(totalcost)
        print("Total area of lawn")
        print(totallawnarea)
        print("Qty of seed required")
        print(Qtyseed)
    }
    















